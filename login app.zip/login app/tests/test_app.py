import importlib
import os
import shutil
import sqlite3
import tempfile
import unittest


class AttendanceAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="attendance-app-")
        cls.db_path = os.path.join(cls.temp_dir, "test_users.db")
        os.environ["ATTENDANCE_DB_PATH"] = cls.db_path
        os.environ["FLASK_SECRET_KEY"] = "test-secret-key"

        import app as attendance_app

        cls.app_module = importlib.reload(attendance_app)
        cls.app = cls.app_module.app
        cls.app.config["TESTING"] = True

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.temp_dir, ignore_errors=True)

    def setUp(self):
        self.client = self.app.test_client()
        self.reset_database()

    def reset_database(self):
        if os.path.exists(self.db_path):
            with sqlite3.connect(self.db_path) as con:
                tables = con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                ).fetchall()
                for (table_name,) in tables:
                    con.execute(f"DROP TABLE IF EXISTS {table_name}")
        self.app_module.initialize_database()

    def insert_student(self, username="student1", rollno=1):
        with self.app_module.db() as con:
            con.execute(
                """
                INSERT INTO users(rollno, username, password, gender, mobile, address, photo, enroll, blood, school, birthdate, role)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rollno,
                    username,
                    self.app_module.generate_password_hash("pass1234"),
                    "Male",
                    "9999999999",
                    "Test Address",
                    "",
                    "ENR001",
                    "O+",
                    "Test School",
                    "2005-01-01",
                    "student",
                ),
            )
            return con.execute(
                "SELECT id FROM users WHERE username=?",
                (username,)
            ).fetchone()["id"]

    def login_admin(self):
        return self.client.post(
            "/admin_login",
            data={"username": "admin", "password": "admin123"},
            follow_redirects=False,
        )

    def login_teacher(self):
        return self.client.post(
            "/teacher_login",
            data={"username": "atmiya", "password": "atmiya123"},
            follow_redirects=False,
        )

    def insert_teacher(self, name, username, course="BCA", subject="Python"):
        with self.app_module.db() as con:
            con.execute(
                """
                INSERT INTO teachers(name, email, mobile, username, course, subject)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (name, f"{username}@example.com", "8888888888", username, course, subject),
            )
            return con.execute(
                "SELECT id FROM teachers WHERE username=?",
                (username,)
            ).fetchone()["id"]

    def test_public_pages_load(self):
        for path in ["/", "/student_login", "/admin_login", "/teacher_login", "/forgot_password"]:
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200, path)

    def test_role_specific_login_is_enforced(self):
        response = self.client.post(
            "/student_login",
            data={"username": "admin", "password": "admin123"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Invalid student login", response.data)

        response = self.login_admin()
        self.assertEqual(response.status_code, 302)
        self.assertIn("/admin", response.headers["Location"])

    def test_admin_can_delete_student(self):
        student_id = self.insert_student(username="delete_me", rollno=10)
        self.login_admin()

        response = self.client.get(f"/delete/{student_id}", follow_redirects=False)

        self.assertEqual(response.status_code, 302)
        self.assertIn("/list", response.headers["Location"])

        with self.app_module.db() as con:
            student = con.execute("SELECT id FROM users WHERE id=?", (student_id,)).fetchone()
        self.assertIsNone(student)

    def test_teacher_attendance_post_redirects_back_to_attendance(self):
        student_id = self.insert_student(username="daily_student", rollno=7)
        self.login_teacher()

        response = self.client.post(
            "/attendance",
            data={
                "date": "2026-03-25",
                f"status_{student_id}": "Present",
            },
            follow_redirects=False,
        )

        self.assertEqual(response.status_code, 302)
        self.assertIn("/attendance?saved=1", response.headers["Location"])

        with self.app_module.db() as con:
            row = con.execute(
                "SELECT status FROM attendance WHERE student_id=? AND date=?",
                (student_id, "2026-03-25"),
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row["status"], "Present")

    def test_admin_dashboard_requires_admin_session(self):
        response = self.client.get("/admin", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/", response.headers["Location"])


    def test_admin_dashboard_shows_student_report_view_action(self):
        self.insert_student(username="report_student", rollno=3)
        self.login_admin()

        response = self.client.get("/admin", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Report", response.data)
        self.assertIn(b">View<", response.data)

    def test_teacher_dashboard_shows_student_report_view_action(self):
        self.insert_student(username="teacher_side_student", rollno=4)
        self.login_teacher()

        response = self.client.get("/teacher", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Student overview table", response.data)
        self.assertIn(b">View<", response.data)


    def test_admin_dashboard_shows_teacher_overview_table(self):
        self.insert_teacher("Faculty Admin View", "facultyadminview")
        self.login_admin()

        response = self.client.get("/admin", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Teacher overview table", response.data)
        self.assertIn(b"/teacher_report/", response.data)


    def test_teacher_can_open_own_teacher_attendance_report(self):
        atmiya_teacher_id = self.insert_teacher("Atmiya Sir", "atmiya")
        other_teacher_id = self.insert_teacher("Other Teacher", "otherteacher")

        with self.app_module.db() as con:
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (atmiya_teacher_id, "2026-03-25", "Present"),
            )
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (other_teacher_id, "2026-03-25", "Absent"),
            )

        self.login_teacher()
        response = self.client.get("/teacher_attendance_report", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Atmiya Sir", response.data)
        self.assertNotIn(b"Other Teacher", response.data)

    def test_teacher_attendance_download_is_filtered_for_logged_in_teacher(self):
        atmiya_teacher_id = self.insert_teacher("Atmiya Sir", "atmiya")
        other_teacher_id = self.insert_teacher("Other Teacher", "otherteacher")

        with self.app_module.db() as con:
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (atmiya_teacher_id, "2026-03-25", "Present"),
            )
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (other_teacher_id, "2026-03-25", "Absent"),
            )

        self.login_teacher()
        response = self.client.get("/teacher_attendance_download", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Atmiya Sir", response.data)
        self.assertNotIn(b"Other Teacher", response.data)


    def test_admin_teachers_list_shows_report_view_action(self):
        self.insert_teacher("Faculty One", "facultyone")
        self.login_admin()

        response = self.client.get("/teachers", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Report", response.data)
        self.assertIn(b">View<", response.data)

    def test_admin_can_open_single_teacher_report(self):
        teacher_one_id = self.insert_teacher("Faculty One", "facultyone")
        teacher_two_id = self.insert_teacher("Faculty Two", "facultytwo")

        with self.app_module.db() as con:
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (teacher_one_id, "2026-03-26", "Present"),
            )
            con.execute(
                "INSERT INTO teacher_attendance(teacher_id, date, status) VALUES (?, ?, ?)",
                (teacher_two_id, "2026-03-26", "Absent"),
            )

        self.login_admin()
        response = self.client.get(f"/teacher_report/{teacher_one_id}", follow_redirects=False)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Faculty One", response.data)
        self.assertNotIn(b"Faculty Two", response.data)


if __name__ == "__main__":
    unittest.main()
