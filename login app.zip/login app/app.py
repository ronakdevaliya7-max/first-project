import io
import sqlite3, os, time
import csv
from datetime import date, timedelta

from flask import Flask, render_template, request, redirect, session, send_from_directory, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "attendance-dev-secret")
app.config["DATABASE_PATH"] = os.environ.get(
    "ATTENDANCE_DB_PATH",
    os.path.join(os.getcwd(), "users.db")
)
app.jinja_env.filters["display_date"] = lambda value: format_display_date(value)

TIMETABLE_META = {
    "title": "DS3 - [B.C.A & B.Sc.I.T. Sem-4]",
    "subtitle": "Classroom no. 208, Computer Lab. 6&8 Ground Floor",
}
TIMETABLE_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
TIMETABLE_ROWS = [
    {
        "number": "1",
        "time": "07:30 to 08:25",
        "courses": {
            "Monday": "",
            "Tuesday": "PHP",
            "Wednesday": "Java",
            "Thursday": "",
            "Friday": "",
            "Saturday": "DBMS",
        },
    },
    {
        "number": "2",
        "time": "08:25 to 09:20",
        "courses": {
            "Monday": "",
            "Tuesday": "Python",
            "Wednesday": "AI",
            "Thursday": "Math",
            "Friday": "",
            "Saturday": "PHP",
        },
    },
    {
        "number": "",
        "time": "09:20 to 09:50",
        "courses": {},
        "is_break": True,
    },
    {
        "number": "3",
        "time": "09:50 to 10:45",
        "courses": {
            "Monday": "DBMS",
            "Tuesday": "Java",
            "Wednesday": "PHP",
            "Thursday": "Python",
            "Friday": "AI",
            "Saturday": "Math",
        },
    },
    {
        "number": "4",
        "time": "10:45 to 11:40",
        "courses": {
            "Monday": "Math",
            "Tuesday": "AI",
            "Wednesday": "",
            "Thursday": "Java",
            "Friday": "DBMS",
            "Saturday": "",
        },
    },
    {
        "number": "",
        "time": "11:40 to 11:50",
        "courses": {},
        "is_break": True,
    },
    {
        "number": "5",
        "time": "11:50 to 12:45",
        "courses": {
            "Monday": "PHP",
            "Tuesday": "Python",
            "Wednesday": "",
            "Thursday": "Math",
            "Friday": "AI",
            "Saturday": "",
        },
    },
    {
        "number": "6",
        "time": "12:45 to 01:40",
        "courses": {
            "Monday": "Java",
            "Tuesday": "",
            "Wednesday": "",
            "Thursday": "",
            "Friday": "DBMS",
            "Saturday": "",
        },
    },
]
TIMETABLE_REQUIRED_SUBJECTS = sorted({
    course
    for row in TIMETABLE_ROWS
    if not row.get("is_break")
    for course in row["courses"].values()
    if course
})

UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# DATABASE
def db():
    con = sqlite3.connect(app.config["DATABASE_PATH"])
    con.row_factory = sqlite3.Row
    return con


def redirect_for_role(role):
    if role == "admin":
        return redirect("/admin")
    if role == "teacher":
        return redirect("/teacher")
    return redirect("/home")


def authenticate_user(username, password):
    with db() as con:
        user = con.execute(
            "SELECT * FROM users WHERE username=?",
            (username,)
        ).fetchone()

    if user and check_password_hash(user["password"], password):
        return user

    return None


def current_user():
    if "user" not in session:
        return None

    with db() as con:
        return con.execute(
            "SELECT * FROM users WHERE username=?",
            (session["user"],)
        ).fetchone()


def current_teacher_record(con=None):
    username = session.get("user")
    if not username:
        return None

    owns_connection = con is None
    if owns_connection:
        con = db()

    try:
        return con.execute(
            """
            SELECT *
            FROM teachers
            WHERE username=?
            ORDER BY id
            LIMIT 1
            """,
            (username,)
        ).fetchone()
    finally:
        if owns_connection:
            con.close()


def get_student_leave_requests(con, status_filter="", limit=None):
    query = """
        SELECT
            student_leaves.id,
            student_leaves.student_id,
            student_leaves.leave_kind,
            student_leaves.leave_type,
            student_leaves.from_date,
            student_leaves.to_date,
            student_leaves.remarks,
            student_leaves.status,
            student_leaves.created_at,
            users.username,
            users.rollno,
            users.enroll
        FROM student_leaves
        JOIN users ON users.id = student_leaves.student_id
        WHERE users.role='student'
    """
    params = []

    if status_filter:
        query += " AND student_leaves.status=?"
        params.append(status_filter)

    query += " ORDER BY student_leaves.from_date DESC, student_leaves.id DESC"

    if limit is not None:
        query += " LIMIT ?"
        params.append(limit)

    return con.execute(query, tuple(params)).fetchall()


def get_attendance_day_name(attendance_date):
    try:
        return date.fromisoformat(attendance_date).strftime("%A")
    except (TypeError, ValueError):
        return ""


def format_display_date(value):
    try:
        return date.fromisoformat(value).strftime("%d-%m-%Y")
    except (TypeError, ValueError):
        return value or "-"


def get_weekly_timetable():
    return {
        "meta": TIMETABLE_META,
        "days": TIMETABLE_DAYS,
        "rows": TIMETABLE_ROWS,
    }


def get_day_timetable_slots(day_name):
    slots = []
    for row in TIMETABLE_ROWS:
        if row.get("is_break"):
            continue
        lecture_name = row["courses"].get(day_name, "")
        if lecture_name:
            slots.append({
                "lecture_name": lecture_name,
                "time": row["time"],
            })
    return slots


def expected_timetable_lecture_count(start_date, total_days):
    total_lectures = 0
    for day_offset in range(total_days):
        current_date = start_date + timedelta(days=day_offset)
        day_name = current_date.strftime("%A")
        if day_name == "Sunday":
            continue
        total_lectures += len(get_day_timetable_slots(day_name))
    return total_lectures


def get_students_on_approved_leave(con, target_date):
    if not target_date:
        return {}

    rows = con.execute(
        """
        SELECT
            student_id,
            leave_kind,
            leave_type,
            from_date,
            to_date
        FROM student_leaves
        WHERE status='Approved'
          AND from_date <= ?
          AND to_date >= ?
        """,
        (target_date, target_date)
    ).fetchall()

    return {
        row["student_id"]: {
            "leave_kind": row["leave_kind"],
            "leave_type": row["leave_type"],
            "from_date": row["from_date"],
            "to_date": row["to_date"],
        }
        for row in rows
    }


def calculate_student_percentage(data):
    def row_value(row, key):
        if isinstance(row, dict):
            return row.get(key)
        return row[key] if key in row.keys() else None

    present = sum(1 for row in data if row["status"] == "Present")
    absent = sum(1 for row in data if row["status"] == "Absent")
    leave = sum(1 for row in data if row["status"] == "Leave")
    eligible_total = present + absent
    base_percent = round((present / eligible_total) * 100) if eligible_total else 0

    ordered_rows = sorted(
        data,
        key=lambda row: (
            row_value(row, "date") or "",
            row_value(row, "time") or "",
            row_value(row, "lecture_name") or "",
        )
    )

    penalty = 0
    recovery = 0
    previous_penalty_status = ""

    for row in ordered_rows:
        status = row["status"]

        if status == "Leave":
            penalty += 10
            previous_penalty_status = "Leave"
        elif status == "Absent":
            penalty += 20
            previous_penalty_status = "Absent"
        elif status == "Present":
            if previous_penalty_status:
                recovery += 5
                previous_penalty_status = ""

    adjusted_percent = max(0, min(100, base_percent - penalty + recovery))

    return {
        "present": present,
        "absent": absent,
        "leave": leave,
        "eligible_total": eligible_total,
        "base_percent": base_percent,
        "penalty": penalty,
        "recovery": recovery,
        "percent": adjusted_percent,
    }


def safe_percent(part, total):
    return round((part * 100 / total), 0) if total else 0


def get_recent_attendance_chart(con, limit=5):
    rows = con.execute(
        """
        SELECT
            lecture_attendance.date,
            SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
        FROM lecture_attendance
        GROUP BY lecture_attendance.date
        ORDER BY lecture_attendance.date DESC
        LIMIT ?
        """,
        (limit,)
    ).fetchall()

    chart_rows = []
    for row in reversed(rows):
        chart_rows.append({
            "label": format_display_date(row["date"]),
            "value": int(safe_percent(row["present_count"] or 0, row["total_count"] or 0)),
        })

    return chart_rows


def get_teacher_snapshot_chart(con):
    all_rows = get_recent_attendance_chart(con, limit=3)
    week_start = (date.today() - timedelta(days=6)).isoformat()
    week_rows = con.execute(
        """
        SELECT
            lecture_attendance.date,
            SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
        FROM lecture_attendance
        WHERE lecture_attendance.date >= ?
        GROUP BY lecture_attendance.date
        ORDER BY lecture_attendance.date DESC
        LIMIT 3
        """,
        (week_start,)
    ).fetchall()

    week_chart = []
    for row in reversed(week_rows):
        week_chart.append({
            "label": format_display_date(row["date"]),
            "value": int(safe_percent(row["present_count"] or 0, row["total_count"] or 0)),
        })

    return {
        "all": all_rows,
        "week": week_chart or all_rows,
    }


def normalize_teacher_username(username):
    cleaned = (username or "").strip().lower()
    if cleaned in {"", "-", "none", "null", "n/a", "na"}:
        return ""
    return cleaned


def build_unique_teacher_username(con, name, preferred_username=""):
    base_username = normalize_teacher_username(preferred_username)
    if not base_username:
        base_username = "".join(ch.lower() for ch in (name or "") if ch.isalnum())
    if not base_username:
        base_username = "teacher"

    candidate = base_username
    suffix = 1
    while con.execute(
        "SELECT 1 FROM users WHERE username=? UNION SELECT 1 FROM teachers WHERE username=?",
        (candidate, candidate)
    ).fetchone():
        candidate = f"{base_username}{suffix}"
        suffix += 1
    return candidate


def build_teacher_username(name, explicit_username=""):
    username = normalize_teacher_username(explicit_username)
    if username:
        return username

    base_username = "".join(ch.lower() for ch in (name or "") if ch.isalnum())
    return base_username or f"teacher{int(time.time())}"


def normalize_teacher_records(con):
    teachers = con.execute(
        "SELECT id, name, username, mobile FROM teachers ORDER BY id"
    ).fetchall()

    for teacher in teachers:
        raw_username = teacher["username"]
        normalized_username = normalize_teacher_username(raw_username)
        linked_user = None

        if raw_username:
            linked_user = con.execute(
                "SELECT id, username FROM users WHERE username=? AND role='teacher'",
                (raw_username,)
            ).fetchone()

        if linked_user and not normalized_username:
            new_username = build_unique_teacher_username(con, teacher["name"])
            con.execute(
                "UPDATE teachers SET username=? WHERE id=?",
                (new_username, teacher["id"])
            )
            con.execute(
                "UPDATE users SET username=? WHERE id=?",
                (new_username, linked_user["id"])
            )
            continue

        if normalized_username and normalized_username != raw_username:
            con.execute(
                "UPDATE teachers SET username=? WHERE id=?",
                (normalized_username, teacher["id"])
            )
            if linked_user:
                con.execute(
                    "UPDATE users SET username=? WHERE id=?",
                    (normalized_username, linked_user["id"])
                )
            continue

        if not normalized_username and teacher["mobile"]:
            mobile_user = con.execute(
                """
                SELECT id, username
                FROM users
                WHERE mobile=? AND role='teacher'
                ORDER BY id
                """,
                (teacher["mobile"],)
            ).fetchone()
            if mobile_user and normalize_teacher_username(mobile_user["username"]):
                con.execute(
                    "UPDATE teachers SET username=? WHERE id=?",
                    (mobile_user["username"], teacher["id"])
                )
                continue

        if not normalized_username:
            con.execute(
                "UPDATE teachers SET username=? WHERE id=?",
                (build_unique_teacher_username(con, teacher["name"]), teacher["id"])
            )


def initialize_database():
    with db() as con:

        # Ensure role exists in users table for admin vs student
        try:
            con.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'student'")
        except sqlite3.OperationalError:
            pass

        con.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rollno INTEGER,
            username TEXT UNIQUE,
            password TEXT,
            gender TEXT,
            mobile TEXT,
            address TEXT,
            photo TEXT,
            enroll TEXT,
            blood TEXT,
            school TEXT,
            birthdate TEXT,
            role TEXT DEFAULT 'student'
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            date TEXT,
            status TEXT
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS lectures(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lecture_date TEXT,
            day TEXT,
            lecture_name TEXT,
            time TEXT
        )
        """)

        try:
            con.execute("ALTER TABLE lectures ADD COLUMN lecture_date TEXT")
        except sqlite3.OperationalError:
            pass

        con.execute("""
        CREATE TABLE IF NOT EXISTS lecture_attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            date TEXT,
            lecture_no INTEGER,
            status TEXT
        )
        """)

        try:
            con.execute("ALTER TABLE lecture_attendance ADD COLUMN lecture_day TEXT")
        except sqlite3.OperationalError:
            pass

        con.execute("""
        CREATE TABLE IF NOT EXISTS student_leaves(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            leave_kind TEXT,
            leave_type TEXT,
            from_date TEXT,
            to_date TEXT,
            remarks TEXT,
            status TEXT DEFAULT 'Pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)

        try:
            con.execute("ALTER TABLE lecture_attendance ADD COLUMN lecture_name TEXT")
        except sqlite3.OperationalError:
            pass

        try:
            con.execute("ALTER TABLE lecture_attendance ADD COLUMN lecture_time TEXT")
        except sqlite3.OperationalError:
            pass

        con.execute("""
        CREATE TABLE IF NOT EXISTS teachers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            mobile TEXT,
            username TEXT,
            course TEXT,
            subject TEXT
        )
        """)

        try:
            con.execute("ALTER TABLE teachers ADD COLUMN username TEXT")
        except sqlite3.OperationalError:
            pass

        con.execute("""
        CREATE TABLE IF NOT EXISTS teacher_attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER,
            date TEXT,
            status TEXT
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS courses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            description TEXT
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS subjects(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            course TEXT
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS lecture_slots(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT,
            end_time TEXT,
            slot_order INTEGER
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS timetable_settings(
            id INTEGER PRIMARY KEY CHECK (id = 1),
            start_date TEXT,
            total_days INTEGER
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS festivals(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            festival_date TEXT,
            day TEXT,
            name TEXT,
            holiday_type TEXT,
            note TEXT
        )
        """)

        admin_user = con.execute("SELECT * FROM users WHERE username=?", ("admin",)).fetchone()
        if not admin_user:
            con.execute("""
            INSERT INTO users(rollno,username,password,gender,mobile,address,photo,enroll,blood,school,birthdate,role)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                0,
                "admin",
                generate_password_hash("admin123"),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "admin"
            ))

        atmiya_user = con.execute("SELECT * FROM users WHERE username=?", ("atmiya",)).fetchone()
        if not atmiya_user:
            con.execute("""
            INSERT INTO users(rollno,username,password,gender,mobile,address,photo,enroll,blood,school,birthdate,role)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                0,
                "atmiya",
                generate_password_hash("atmiya123"),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "teacher"
            ))

        default_course = "BCA"
        default_subjects = TIMETABLE_REQUIRED_SUBJECTS

        existing_course = con.execute(
            "SELECT id FROM courses WHERE name=?",
            (default_course,)
        ).fetchone()
        if not existing_course:
            con.execute(
                "INSERT INTO courses(name,description) VALUES (?,?)",
                (default_course, "Default course")
            )

        for subject_name in default_subjects:
            existing_subject = con.execute(
                "SELECT id FROM subjects WHERE name=? AND course=?",
                (subject_name, default_course)
            ).fetchone()
            if not existing_subject:
                con.execute(
                    "INSERT INTO subjects(name,course) VALUES (?,?)",
                    (subject_name, default_course)
                )

        default_slots = [
            ("07:30", "08:25", 1),
            ("08:25", "09:20", 2),
            ("09:50", "10:45", 3),
            ("10:45", "11:40", 4),
            ("11:50", "12:45", 5),
            ("12:45", "01:40", 6),
        ]
        slot_count = con.execute("SELECT COUNT(*) FROM lecture_slots").fetchone()[0]
        if slot_count == 0:
            con.executemany(
                "INSERT INTO lecture_slots(start_time,end_time,slot_order) VALUES (?,?,?)",
                default_slots
            )

        settings = con.execute("SELECT id FROM timetable_settings WHERE id=1").fetchone()
        if not settings:
            con.execute(
                "INSERT INTO timetable_settings(id,start_date,total_days) VALUES (1,?,?)",
                (date.today().isoformat(), 180)
            )

        con.execute("""
        UPDATE lecture_attendance
        SET
            lecture_day = COALESCE(
                NULLIF(lecture_day, ''),
                (SELECT day FROM lectures WHERE lectures.id = lecture_attendance.lecture_no)
            ),
            lecture_name = COALESCE(
                NULLIF(lecture_name, ''),
                (SELECT lecture_name FROM lectures WHERE lectures.id = lecture_attendance.lecture_no)
            ),
            lecture_time = COALESCE(
                NULLIF(lecture_time, ''),
                (SELECT time FROM lectures WHERE lectures.id = lecture_attendance.lecture_no)
            )
        WHERE
            COALESCE(lecture_day, '') = ''
            OR COALESCE(lecture_name, '') = ''
            OR COALESCE(lecture_time, '') = ''
        """)

        normalize_teacher_records(con)


def get_lecture_attendance_rows(con, where_clause="", params=()):
    query = f"""
    WITH dated_lectures AS (
        SELECT
            id,
            lecture_date,
            day,
            lecture_name,
            time,
            ROW_NUMBER() OVER (
                PARTITION BY lecture_date
                ORDER BY id
            ) AS slot_no
        FROM lectures
    ),
    attendance_slots AS (
        SELECT
            date,
            lecture_no,
            DENSE_RANK() OVER (
                PARTITION BY date
                ORDER BY lecture_no
            ) AS slot_no
        FROM (
            SELECT DISTINCT date, lecture_no
            FROM lecture_attendance
        )
    )
    SELECT
        lecture_attendance.date,
        COALESCE(
            NULLIF(lecture_attendance.lecture_day, ''),
            exact_lecture.day,
            slot_lecture.day,
            CASE strftime('%w', lecture_attendance.date)
                WHEN '0' THEN 'Sunday'
                WHEN '1' THEN 'Monday'
                WHEN '2' THEN 'Tuesday'
                WHEN '3' THEN 'Wednesday'
                WHEN '4' THEN 'Thursday'
                WHEN '5' THEN 'Friday'
                WHEN '6' THEN 'Saturday'
            END
        ) AS day,
        COALESCE(
            NULLIF(lecture_attendance.lecture_name, ''),
            exact_lecture.lecture_name,
            slot_lecture.lecture_name,
            CASE
                WHEN attendance_slots.slot_no IS NOT NULL THEN 'Lecture ' || attendance_slots.slot_no
            END
        ) AS lecture_name,
        COALESCE(
            NULLIF(lecture_attendance.lecture_time, ''),
            exact_lecture.time,
            slot_lecture.time,
            CASE
                WHEN lecture_slot.start_time IS NOT NULL AND lecture_slot.end_time IS NOT NULL
                THEN lecture_slot.start_time || ' - ' || lecture_slot.end_time
            END
        ) AS time,
        users.username,
        lecture_attendance.status
    FROM lecture_attendance
    JOIN users ON users.id = lecture_attendance.student_id
    LEFT JOIN dated_lectures AS exact_lecture
        ON exact_lecture.id = lecture_attendance.lecture_no
    LEFT JOIN attendance_slots
        ON attendance_slots.date = lecture_attendance.date
        AND attendance_slots.lecture_no = lecture_attendance.lecture_no
    LEFT JOIN dated_lectures AS slot_lecture
        ON slot_lecture.lecture_date = lecture_attendance.date
        AND slot_lecture.slot_no = attendance_slots.slot_no
        AND exact_lecture.id IS NULL
    LEFT JOIN lecture_slots AS lecture_slot
        ON lecture_slot.slot_order = attendance_slots.slot_no
    {where_clause}
    ORDER BY
        lecture_attendance.date DESC,
        COALESCE(
            NULLIF(lecture_attendance.lecture_time, ''),
            exact_lecture.time,
            slot_lecture.time,
            lecture_slot.start_time
        ),
        lecture_attendance.lecture_no,
        users.username
    """
    return con.execute(query, params).fetchall()


def get_student_attendance_report(student_id):
    with db() as con:
        student = con.execute(
            "SELECT id, username, rollno FROM users WHERE id=?",
            (student_id,)
        ).fetchone()

        lecture_data = get_lecture_attendance_rows(
            con,
            "WHERE lecture_attendance.student_id=?",
            (student_id,)
        )

        if lecture_data:
            data = [
                {
                    "date": row["date"],
                    "day": row["day"],
                    "lecture_name": row["lecture_name"],
                    "time": row["time"],
                    "status": row["status"],
                }
                for row in lecture_data
            ]
            report_type = "lecture"
        else:
            data = con.execute("""
            SELECT
                date,
                '' AS day,
                '' AS lecture_name,
                '' AS time,
                status
            FROM attendance
            WHERE student_id=?
            ORDER BY date DESC
            """, (student_id,)).fetchall()
            report_type = "daily"

    score = calculate_student_percentage(data)

    return {
        "student": student,
        "data": data,
        "present": score["present"],
        "absent": score["absent"],
        "leave": score["leave"],
        "base_percent": score["base_percent"],
        "penalty": score["penalty"],
        "recovery": score["recovery"],
        "percent": score["percent"],
        "report_type": report_type,
    }


def get_teacher_attendance_report(selected_date="", teacher_username="", teacher_id=None):
    with db() as con:
        teacher_filter = normalize_teacher_username(teacher_username)
        join_clause = "LEFT JOIN teacher_attendance ON teacher_attendance.teacher_id = teachers.id"
        summary_params = []
        if selected_date:
            join_clause = """
            LEFT JOIN teacher_attendance
                ON teacher_attendance.teacher_id = teachers.id
                AND teacher_attendance.date=?
            """
            summary_params.append(selected_date)

        summary_query = f"""
        SELECT
            teachers.id,
            TRIM(teachers.name) AS name,
            teachers.username,
            teachers.course,
            teachers.subject,
            SUM(CASE WHEN teacher_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN teacher_attendance.status='Absent' THEN 1 ELSE 0 END) AS absent_count,
            COUNT(teacher_attendance.id) AS total_count
        FROM teachers
        {join_clause}
        """
        detail_query = """
        SELECT
            teacher_attendance.date,
            teachers.id AS teacher_id,
            TRIM(teachers.name) AS name,
            teachers.username,
            teachers.course,
            teachers.subject,
            teacher_attendance.status
        FROM teacher_attendance
        JOIN teachers ON teachers.id = teacher_attendance.teacher_id
        """

        summary_where_parts = []
        detail_where_parts = []
        detail_params = []

        if teacher_filter:
            summary_where_parts.append("teachers.username=?")
            summary_params.append(teacher_filter)
            detail_where_parts.append("teachers.username=?")
            detail_params.append(teacher_filter)

        if teacher_id is not None:
            summary_where_parts.append("teachers.id=?")
            summary_params.append(teacher_id)
            detail_where_parts.append("teachers.id=?")
            detail_params.append(teacher_id)

        if selected_date:
            detail_where_parts.append("teacher_attendance.date=?")
            detail_params.append(selected_date)

        if summary_where_parts:
            summary_query += " WHERE " + " AND ".join(summary_where_parts)

        where_clause = ""
        if detail_where_parts:
            where_clause = " WHERE " + " AND ".join(detail_where_parts)

        summary = con.execute(
            summary_query + """
            GROUP BY teachers.id, teachers.name, teachers.username, teachers.course, teachers.subject
            ORDER BY TRIM(teachers.name), teachers.id
            """,
            tuple(summary_params)
        ).fetchall()

        details = con.execute(
            detail_query + where_clause + """
            ORDER BY teacher_attendance.date DESC, TRIM(teachers.name), teachers.id
            """,
            tuple(detail_params)
        ).fetchall()

    total_present = sum((row["present_count"] or 0) for row in summary)
    total_absent = sum((row["absent_count"] or 0) for row in summary)
    total_records = sum((row["total_count"] or 0) for row in summary)
    overall_percent = round((total_present / total_records) * 100) if total_records else 0

    chart_labels = [row["name"] or row["username"] or f"Teacher {row['id']}" for row in summary]
    chart_present = [row["present_count"] or 0 for row in summary]
    chart_absent = [row["absent_count"] or 0 for row in summary]

    return {
        "selected_date": selected_date,
        "summary": summary,
        "details": details,
        "total_present": total_present,
        "total_absent": total_absent,
        "total_records": total_records,
        "overall_percent": overall_percent,
        "chart_labels": chart_labels,
        "chart_present": chart_present,
        "chart_absent": chart_absent,
    }


def can_access_teacher_report(target_teacher_id):
    if "user" not in session:
        return False

    role = session.get("role")
    if role == "admin":
        return True

    if role != "teacher":
        return False

    with db() as con:
        teacher = current_teacher_record(con)
        return bool(teacher and teacher["id"] == target_teacher_id)


initialize_database()


# IMAGE VIEW
@app.route("/uploads/<filename>")
def uploaded(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


def get_timetable_settings(con):
    settings = con.execute(
        "SELECT start_date, total_days FROM timetable_settings WHERE id=1"
    ).fetchone()
    if not settings:
        return date.today().isoformat(), 180
    start_date = settings["start_date"] or date.today().isoformat()
    total_days = settings["total_days"] or 180
    try:
        date.fromisoformat(start_date)
    except ValueError:
        start_date = date.today().isoformat()
    if total_days < 1:
        total_days = 180
    return start_date, total_days


def ensure_six_month_timetable(con, reset=False):
    start_date_text, total_days = get_timetable_settings(con)
    start_date = date.fromisoformat(start_date_text)
    expected_lecture_count = expected_timetable_lecture_count(start_date, total_days)
    lecture_count = con.execute("SELECT COUNT(*) FROM lectures").fetchone()[0]
    valid_dates_count = con.execute(
        "SELECT COUNT(*) FROM lectures WHERE lecture_date IS NOT NULL AND lecture_date != ''"
    ).fetchone()[0]
    first_lecture = con.execute(
        """
        SELECT lecture_name, time
        FROM lectures
        ORDER BY lecture_date, id
        LIMIT 1
        """
    ).fetchone()
    expected_first_lecture = None

    for day_offset in range(total_days):
        current_date = start_date + timedelta(days=day_offset)
        slots = get_day_timetable_slots(current_date.strftime("%A"))
        if slots:
            expected_first_lecture = slots[0]
            break

    if (
        not reset
        and lecture_count == expected_lecture_count
        and valid_dates_count == expected_lecture_count
        and first_lecture
        and expected_first_lecture
        and first_lecture["lecture_name"] == expected_first_lecture["lecture_name"]
        and first_lecture["time"] == expected_first_lecture["time"]
    ):
        return

    con.execute("DELETE FROM lectures")

    for day_offset in range(total_days):
        current_date = start_date + timedelta(days=day_offset)
        day_name = current_date.strftime("%A")
        if day_name == "Sunday":
            continue

        for slot in get_day_timetable_slots(day_name):
            con.execute("""
            INSERT INTO lectures(lecture_date,day,lecture_name,time)
            VALUES (?,?,?,?)
            """, (current_date.isoformat(), day_name, slot["lecture_name"], slot["time"]))


def ensure_festival_calendar(con, reset=False):
    festival_rows = con.execute("""
        SELECT id, festival_date
        FROM festivals
        WHERE festival_date IS NOT NULL AND festival_date != ''
    """).fetchall()

    for row in festival_rows:
        day = date.fromisoformat(row["festival_date"]).strftime("%A")
        con.execute("UPDATE festivals SET day=? WHERE id=?", (day, row["id"]))


# LANDING PAGE
@app.route("/")
def index():
    if "user" in session:
        return redirect_for_role(session.get("role"))
    return render_template("index.html")


# STUDENT LOGIN
@app.route("/student_login", methods=["GET","POST"])
def student_login():
    msg=""

    if request.method=="POST":

        username=request.form["username"]
        password=request.form["password"]

        user = authenticate_user(username, password)

        if user and user["role"] == "student":
            session["user"]=username
            session["role"]= user["role"] if user["role"] else "student"
            return redirect_for_role(session["role"])

        else:
            msg="Invalid student login"

    return render_template("login.html",msg=msg, role="student")


# LOGIN (kept for backward compatibility)
@app.route("/login", methods=["GET","POST"])
def login():
    msg=""

    if request.method=="POST":

        username=request.form["username"]
        password=request.form["password"]

        user = authenticate_user(username, password)

        if user:
            session["user"]=username
            session["role"]= user["role"] if user["role"] else "student"
            return redirect_for_role(session["role"])

        else:
            msg="Invalid Login"

    return render_template("login.html",msg=msg)


@app.route("/admin_login", methods=["GET","POST"])
def admin_login():
    msg=""
    if request.method=="POST":
        username=request.form["username"]
        password=request.form["password"]
        user = authenticate_user(username, password)
        if user and user["role"] == "admin":
            session["user"]=username
            session["role"]= user["role"] if user["role"] else "student"
            return redirect_for_role(session["role"])
        msg="Invalid admin login"
    return render_template("login.html", msg=msg, role="admin")


@app.route("/teacher_login", methods=["GET","POST"])
def teacher_login():
    msg=""
    if request.method=="POST":
        username=request.form["username"]
        password=request.form["password"]
        user = authenticate_user(username, password)
        if user and user["role"] == "teacher":
            session["user"]=username
            session["role"]= user["role"] if user["role"] else "student"
            return redirect_for_role(session["role"])
        msg="Invalid teacher login"
    return render_template("login.html", msg=msg, role="teacher")


@app.route("/teacher")
def teacher_dashboard():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "teacher":
        return redirect("/")
    with db() as con:
        user = con.execute("SELECT * FROM users WHERE username=?", (session["user"],)).fetchone()
        today_text = date.today().isoformat()
        students = con.execute("""
            SELECT
                users.*,
                users.username AS name,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE role='student'
            GROUP BY users.id
            ORDER BY rollno, name
            LIMIT 50
        """).fetchall()
        lectures = con.execute("""
            SELECT id, lecture_date, lecture_name, time
            FROM lectures
            ORDER BY lecture_date DESC, id DESC
            LIMIT 20
        """).fetchall()
        leave_requests = get_student_leave_requests(con, limit=10)
        today_classes = con.execute(
            "SELECT COUNT(*) FROM lectures WHERE lecture_date=?",
            (today_text,)
        ).fetchone()[0]
        student_count = con.execute(
            "SELECT COUNT(*) FROM users WHERE role='student'"
        ).fetchone()[0]
        lecture_records_today = con.execute(
            """
            SELECT COUNT(*)
            FROM lecture_attendance
            WHERE date=? AND status IN ('Present', 'Absent', 'Leave')
            """,
            (today_text,)
        ).fetchone()[0]
        expected_today_records = student_count * today_classes
        lecture_flow_percent = int(safe_percent(lecture_records_today, expected_today_records)) if expected_today_records else 0
        weekly_rows = con.execute(
            """
            SELECT COUNT(*)
            FROM lecture_attendance
            WHERE date >= ?
            """,
            ((date.today() - timedelta(days=6)).isoformat(),)
        ).fetchone()[0]
        teacher_chart = get_teacher_snapshot_chart(con)

    search_items = [
        {"label": "Daily Attendance", "meta": "Open attendance sheet", "url": "/attendance"},
        {"label": "Lecture Attendance", "meta": "Mark lecture-wise attendance", "url": "/lecture_attendance"},
        {"label": "Timetable", "meta": "Open lecture timetable", "url": "/timetable"},
        {"label": "Weekly Report", "meta": "Open weekly attendance report", "url": "/weekly_attendance"},
        {"label": "Teacher Attendance Report", "meta": "Open teacher attendance summary", "url": "/teacher_attendance_report"},
        {"label": "Festival Calendar", "meta": "View festival dates", "url": "/festivals"},
    ]

    for student in students:
        student_name = student["name"] or student["username"] or f"Student {student['id']}"
        search_items.append({
            "label": student_name,
            "meta": f"Student report | Roll No: {student['rollno'] or '-'}",
            "url": f"/report/{student['id']}"
        })

    for lecture in lectures:
        lecture_date = lecture["lecture_date"] or "No date"
        lecture_name = lecture["lecture_name"] or f"Lecture {lecture['id']}"
        lecture_time = lecture["time"] or "Time pending"
        search_items.append({
            "label": lecture_name,
            "meta": f"{lecture_date} | {lecture_time}",
            "url": "/lecture_attendance"
        })

    return render_template(
        "teacher.html",
        user=user,
        students=students,
        search_items=search_items,
        leave_requests=leave_requests,
        today_classes=today_classes,
        lecture_flow_percent=lecture_flow_percent,
        weekly_rows=weekly_rows,
        teacher_chart=teacher_chart,
        weekly_timetable=get_weekly_timetable(),
    )


# FORGOT PASSWORD
@app.route("/forgot_password", methods=["GET","POST"])
def forgot_password():
    msg = ""
    success = ""
    
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        new_password = request.form.get("new_password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()
        
        if not username or not new_password or not confirm_password:
            msg = "All fields are required"
        elif new_password != confirm_password:
            msg = "Passwords do not match"
        elif len(new_password) < 4:
            msg = "Password must be at least 4 characters"
        else:
            with db() as con:
                user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
                if not user:
                    msg = "Username not found"
                else:
                    hashed_password = generate_password_hash(new_password)
                    con.execute("UPDATE users SET password=? WHERE username=?", (hashed_password, username))
                    success = "Password reset successfully! Please login with your new password."
    
    return render_template("forgot_password.html", msg=msg, success=success)


# SIGNUP
@app.route("/signup", methods=["GET","POST"])
def signup():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    if request.method == "POST":

        f = request.form
        file = request.files.get("photo")

        filename = ""

        if file and file.filename != "":
            filename = str(time.time()) + "_" + secure_filename(file.filename)
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

        with db() as con:

            check = con.execute(
                "SELECT * FROM users WHERE username=?",
                (f["username"],)
            ).fetchone()

            if check:
                return render_template("signup.html", msg="Username already exists")

            con.execute("""
            INSERT INTO users
            (rollno,username,password,gender,mobile,address,photo,enroll,blood,school,birthdate,role)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """,(
                f["rollno"],
                f["username"],
                generate_password_hash(f["password"]),
                f["gender"],
                f["mobile"],
                f["address"],
                filename,
                f["enroll"],
                f["blood"],
                f["school"],
                f["birthdate"],
                "student"
            ))

        return redirect("/list")

    return render_template("signup.html", msg="")


# HOME
@app.route("/home")
def home():
    if "user" not in session:
        return redirect("/")

    if session.get("role") == "admin":
        return redirect("/admin")
    if session.get("role") == "teacher":
        return redirect("/teacher")

    with db() as con:
        user = con.execute(
            "SELECT * FROM users WHERE username=?",
            (session["user"],)
        ).fetchone()

        total = con.execute(
            "SELECT COUNT(*) FROM users WHERE role='student'"
        ).fetchone()[0]
        recent_leaves = con.execute(
            """
            SELECT leave_kind, leave_type, from_date, to_date, status
            FROM student_leaves
            WHERE student_id=?
            ORDER BY from_date DESC, id DESC
            LIMIT 3
            """,
            (user["id"],)
        ).fetchall()

        ensure_six_month_timetable(con)
        upcoming_lectures = con.execute(
            """
            SELECT lecture_date, lecture_name, time
            FROM lectures
            WHERE lecture_date >= ?
            ORDER BY lecture_date, id
            LIMIT 3
            """,
            (date.today().isoformat(),)
        ).fetchall()

    report_data = get_student_attendance_report(user["id"])
    leave_request_count = len(recent_leaves)
    latest_leave_status = recent_leaves[0]["status"] if recent_leaves else "No Request"

    return render_template(
        "home.html",
        user=user,
        total=total,
        attendance_percent=report_data["percent"],
        present_count=report_data["present"],
        absent_count=report_data["absent"],
        leave_count=report_data["leave"],
        leave_request_count=leave_request_count,
        attendance_penalty=report_data["penalty"],
        attendance_recovery=report_data["recovery"],
        latest_leave_status=latest_leave_status,
        recent_leaves=recent_leaves,
        upcoming_lectures=upcoming_lectures,
        weekly_timetable=get_weekly_timetable(),
    )


@app.route("/student_leave", methods=["GET", "POST"])
def student_leave():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "student":
        return redirect_for_role(session.get("role"))

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    message = ""
    error = ""

    leave_kind_options = [
        "Medical Leave",
        "Cultural Leave",
        "Personal Leave",
        "Family Leave",
        "Emergency Leave",
        "Sports Leave",
    ]
    leave_type_options = [
        "Partially Leave",
        "Full Leave",
    ]

    form_data = {
        "leave_kind": "",
        "leave_type": "",
        "from_date": "",
        "to_date": "",
        "remarks": "",
    }

    with db() as con:
        if request.method == "POST":
            form_data = {
                "leave_kind": request.form.get("leave_kind", "").strip(),
                "leave_type": request.form.get("leave_type", "").strip(),
                "from_date": request.form.get("from_date", "").strip(),
                "to_date": request.form.get("to_date", "").strip(),
                "remarks": request.form.get("remarks", "").strip(),
            }

            if not all(form_data.values()):
                error = "All leave details are required."
            elif form_data["leave_kind"] not in leave_kind_options:
                error = "Please select a valid kind of leave."
            elif form_data["leave_type"] not in leave_type_options:
                error = "Please select a valid type of leave."
            else:
                try:
                    from_dt = date.fromisoformat(form_data["from_date"])
                    to_dt = date.fromisoformat(form_data["to_date"])
                except ValueError:
                    error = "Please choose valid leave dates."
                else:
                    if to_dt < from_dt:
                        error = "To date cannot be earlier than from date."

            if not error:
                con.execute(
                    """
                    INSERT INTO student_leaves(
                        student_id, leave_kind, leave_type, from_date, to_date, remarks, status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        user["id"],
                        form_data["leave_kind"],
                        form_data["leave_type"],
                        form_data["from_date"],
                        form_data["to_date"],
                        form_data["remarks"],
                        "Pending",
                    ),
                )
                message = "Leave application saved successfully."
                form_data = {
                    "leave_kind": "",
                    "leave_type": "",
                    "from_date": "",
                    "to_date": "",
                    "remarks": "",
                }

        leave_rows = con.execute(
            """
            SELECT id, leave_kind, leave_type, from_date, to_date, remarks, status, created_at
            FROM student_leaves
            WHERE student_id=?
            ORDER BY from_date DESC, id DESC
            """,
            (user["id"],)
        ).fetchall()

    leave_history = []
    for row in leave_rows:
        from_iso = row["from_date"] or ""
        to_iso = row["to_date"] or ""
        leave_history.append({
            "id": row["id"],
            "leave_kind": row["leave_kind"],
            "leave_type": row["leave_type"],
            "from_date": from_iso,
            "to_date": to_iso,
            "from_display": date.fromisoformat(from_iso).strftime("%d/%m/%Y") if from_iso else "-",
            "to_display": date.fromisoformat(to_iso).strftime("%d/%m/%Y") if to_iso else "-",
            "remarks": row["remarks"] or "-",
            "status": row["status"] or "Pending",
        })

    return render_template(
        "student_leave.html",
        user=user,
        message=message,
        error=error,
        form_data=form_data,
        leave_kind_options=leave_kind_options,
        leave_type_options=leave_type_options,
        leave_history=leave_history,
    )


@app.route("/student_leave/<int:id>/decision", methods=["POST"])
def student_leave_decision(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect_for_role(session.get("role"))

    decision = (request.form.get("decision") or "").strip().lower()
    status_map = {
        "approve": "Approved",
        "reject": "Rejected",
        "pending": "Pending",
    }
    status = status_map.get(decision)
    if not status:
        return redirect("/admin" if session.get("role") == "admin" else "/teacher")

    with db() as con:
        con.execute(
            "UPDATE student_leaves SET status=? WHERE id=?",
            (status, id)
        )

    next_url = request.form.get("next") or ("/admin" if session.get("role") == "admin" else "/teacher")
    return redirect(next_url)


# STUDENT LIST
@app.route("/list")
def list_users():

    if "user" not in session:
        return redirect("/")

    if session.get("role") != "admin":
        return redirect("/admin_login")

    with db() as con:

        users=con.execute("""
            SELECT * FROM users
            WHERE role='student'
            ORDER BY rollno, username
        """).fetchall()

    return render_template("list.html",users=users)


# ADMIN DASHBOARD
@app.route("/admin")
def admin():

    if "user" not in session:
        return redirect("/")

    if session.get("role") != "admin":
        return redirect("/admin_login")

    with db() as con:
        admin_user = con.execute(
            "SELECT * FROM users WHERE username=?",
            (session["user"],)
        ).fetchone()
        users = con.execute("""
            SELECT
                users.*,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE users.role='student'
            GROUP BY users.id
            ORDER BY users.rollno, users.username
        """).fetchall()
        teachers = con.execute("""
            SELECT
                teachers.*,
                SUM(CASE WHEN teacher_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                COUNT(teacher_attendance.id) AS total_count
            FROM teachers
            LEFT JOIN teacher_attendance ON teacher_attendance.teacher_id = teachers.id
            GROUP BY teachers.id
            ORDER BY TRIM(teachers.name), teachers.username
            LIMIT 30
        """).fetchall()
        leave_requests = get_student_leave_requests(con, limit=12)
        student_present_total = sum((row["present_count"] or 0) for row in users)
        student_record_total = sum((row["total_count"] or 0) for row in users)
        attendance_health = int(safe_percent(student_present_total, student_record_total))
        course_count = con.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
        subject_count = con.execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
        lecture_slot_count = con.execute("SELECT COUNT(*) FROM lecture_slots").fetchone()[0]
        open_modules = course_count + subject_count + lecture_slot_count
        reports_ready = len(users) + len(teachers)
        attendance_trend = get_recent_attendance_chart(con, limit=5)

    search_items = [
        {"label": "Student List", "meta": "View all students", "url": "/list"},
        {"label": "Teachers List", "meta": "Manage teacher records", "url": "/teachers"},
        {"label": "Attendance", "meta": "Open daily attendance", "url": "/attendance"},
        {"label": "Lecture Attendance", "meta": "Open lecture attendance", "url": "/lecture_attendance"},
        {"label": "Teacher Attendance", "meta": "Track teacher attendance", "url": "/teacher_attendance"},
        {"label": "Courses", "meta": "Manage courses", "url": "/courses"},
        {"label": "Subjects", "meta": "Manage subjects", "url": "/subjects"},
        {"label": "Weekly Report", "meta": "Open weekly attendance report", "url": "/weekly_attendance"},
        {"label": "Timetable", "meta": "Open lecture timetable", "url": "/timetable"},
    ]

    for student in users[:50]:
        search_items.append({
            "label": student["username"],
            "meta": f"Student report | Roll No: {student['rollno'] or '-'}",
            "url": f"/report/{student['id']}"
        })

    for teacher in teachers:
        teacher_name = teacher["name"] or teacher["username"] or "Teacher"
        teacher_username = teacher["username"] or "-"
        teacher_subject = teacher["subject"] or "No subject assigned"
        search_items.append({
            "label": teacher_name,
            "meta": f"Teacher | {teacher_subject} | {teacher_username}",
            "url": f"/teacher_report/{teacher['id']}"
        })

    return render_template(
        "admin/admin.html",
        users=users,
        teachers=teachers,
        admin_user=admin_user,
        search_items=search_items,
        leave_requests=leave_requests,
        attendance_health=attendance_health,
        open_modules=open_modules,
        reports_ready=reports_ready,
        attendance_trend=attendance_trend,
        weekly_timetable=get_weekly_timetable(),
    )


# TEACHER CRUD
@app.route("/teachers")
def list_teachers():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        normalize_teacher_records(con)
        teachers = con.execute("SELECT * FROM teachers").fetchall()
    return render_template("admin/teachers.html", teachers=teachers)


@app.route("/add_teacher", methods=["GET", "POST"])
def add_teacher():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    msg = ""
    if request.method == "POST":
        f = request.form
        course = f.get("course")
        new_course = f.get("new_course")
        subject = f.get("subject")
        new_subject = f.get("new_subject")
        username = build_teacher_username(f.get("name"), f.get("username"))
        password = (f.get("password") or "").strip()

        with db() as con:
            existing_user = con.execute(
                "SELECT id FROM users WHERE username=?",
                (username,)
            ).fetchone()
            if existing_user:
                msg = "Teacher username already exists."
            elif not password:
                msg = "Password is required for teacher login."
            else:
                if new_course and new_course.strip():
                    course = new_course.strip()
                    existing_course = con.execute("SELECT id FROM courses WHERE name=?", (course,)).fetchone()
                    if not existing_course:
                        con.execute("INSERT INTO courses(name,description) VALUES (?,?)", (course, f.get("course_description", "Added from teacher")))

                if new_subject and new_subject.strip():
                    subject = new_subject.strip()
                    existing_subject = con.execute("SELECT id FROM subjects WHERE name=?", (subject,)).fetchone()
                    if not existing_subject:
                        con.execute("INSERT INTO subjects(name,course) VALUES (?,?)", (subject, course or ""))

                con.execute(
                    "INSERT INTO teachers(name,email,mobile,username,course,subject) VALUES (?,?,?,?,?,?)",
                    (f.get("name"), f.get("email"), f.get("mobile"), username, course, subject)
                )
                con.execute("""
                INSERT INTO users(rollno,username,password,gender,mobile,address,photo,enroll,blood,school,birthdate,role)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    0,
                    username,
                    generate_password_hash(password),
                    "",
                    f.get("mobile"),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "teacher"
                ))
                return redirect("/teachers")

    courses = []
    subjects = []
    with db() as con:
        courses = con.execute("SELECT name FROM courses").fetchall()
        subjects = con.execute("SELECT name FROM subjects").fetchall()
    return render_template("admin/add_teacher.html", courses=courses, subjects=subjects, msg=msg)


@app.route("/edit_teacher/<int:id>", methods=["GET", "POST"])
def edit_teacher(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        teacher = con.execute("SELECT * FROM teachers WHERE id=?", (id,)).fetchone()
        if teacher is None:
            return redirect("/teachers")

        if request.method == "POST":
            f = request.form
            username = build_teacher_username(f.get("name"), f.get("username"))
            new_password = (f.get("password") or "").strip()
            existing_user = con.execute(
                "SELECT id FROM users WHERE username=? AND username<>?",
                (username, teacher["username"] or "")
            ).fetchone()

            if existing_user:
                courses = con.execute("SELECT name FROM courses").fetchall()
                subjects = con.execute("SELECT name FROM subjects").fetchall()
                return render_template(
                    "admin/edit_teacher.html",
                    teacher=teacher,
                    courses=courses,
                    subjects=subjects,
                    msg="Teacher username already exists."
                )

            con.execute("UPDATE teachers SET name=?, email=?, mobile=?, username=?, course=?, subject=? WHERE id=?", (
                f.get("name"), f.get("email"), f.get("mobile"), username, f.get("course"), f.get("subject"), id
            ))
            teacher_user = con.execute(
                "SELECT id FROM users WHERE (username=? OR username=?) AND role='teacher'",
                (teacher["username"] or "", username)
            ).fetchone()
            if teacher_user:
                con.execute(
                    "UPDATE users SET username=?, mobile=? WHERE id=?",
                    (username, f.get("mobile"), teacher_user["id"])
                )
                if new_password:
                    con.execute(
                        "UPDATE users SET password=? WHERE id=?",
                        (generate_password_hash(new_password), teacher_user["id"])
                    )
            else:
                con.execute("""
                INSERT INTO users(rollno,username,password,gender,mobile,address,photo,enroll,blood,school,birthdate,role)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    0,
                    username,
                    generate_password_hash(new_password or "teacher123"),
                    "",
                    f.get("mobile"),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "teacher"
                ))
            return redirect("/teachers")
        courses = con.execute("SELECT name FROM courses").fetchall()
        subjects = con.execute("SELECT name FROM subjects").fetchall()

    return render_template("admin/edit_teacher.html", teacher=teacher, courses=courses, subjects=subjects, msg="")


@app.route("/delete_teacher/<int:id>")
def delete_teacher(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        teacher = con.execute("SELECT username FROM teachers WHERE id=?", (id,)).fetchone()
        con.execute("DELETE FROM teachers WHERE id=?", (id,))
        con.execute("DELETE FROM teacher_attendance WHERE teacher_id=?", (id,))
        if teacher and teacher["username"]:
            con.execute("DELETE FROM users WHERE username=? AND role='teacher'", (teacher["username"],))
    return redirect("/teachers")


@app.route("/delete/<int:id>")
def delete_student(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect("/admin_login")

    with db() as con:
        student = con.execute(
            "SELECT photo FROM users WHERE id=? AND role='student'",
            (id,)
        ).fetchone()
        if student:
            con.execute("DELETE FROM attendance WHERE student_id=?", (id,))
            con.execute("DELETE FROM lecture_attendance WHERE student_id=?", (id,))
            con.execute("DELETE FROM users WHERE id=? AND role='student'", (id,))

            if student["photo"]:
                photo_path = os.path.join(app.config["UPLOAD_FOLDER"], student["photo"])
                if os.path.exists(photo_path):
                    os.remove(photo_path)

    return redirect("/list" if session.get("role") == "admin" else "/teacher")


@app.route("/teacher_attendance", methods=["GET", "POST"])
def teacher_attendance():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    selected_date = request.form.get("date") if request.method == "POST" else request.args.get("date", date.today().isoformat())
    selected_date = selected_date or date.today().isoformat()
    success = request.args.get("saved", "")

    with db() as con:
        teachers = con.execute(
            "SELECT * FROM teachers ORDER BY TRIM(name), id"
        ).fetchall()

        if request.method == "POST":
            for teacher in teachers:
                status = request.form.get(f"status_{teacher['id']}")
                if not status:
                    continue

                existing = con.execute(
                    "SELECT id FROM teacher_attendance WHERE teacher_id=? AND date=?",
                    (teacher["id"], selected_date)
                ).fetchone()

                if existing:
                    con.execute(
                        "UPDATE teacher_attendance SET status=? WHERE teacher_id=? AND date=?",
                        (status, teacher["id"], selected_date)
                    )
                else:
                    con.execute(
                        "INSERT INTO teacher_attendance(teacher_id,date,status) VALUES (?,?,?)",
                        (teacher["id"], selected_date, status)
                    )
            return redirect(f"/teacher_attendance?date={selected_date}&saved=1")

        attendance_map = {
            row["teacher_id"]: row["status"]
            for row in con.execute(
                "SELECT teacher_id, status FROM teacher_attendance WHERE date=?",
                (selected_date,)
            ).fetchall()
        }
        recent_rows = con.execute("""
        SELECT teacher_attendance.date, teachers.id AS teacher_id, TRIM(teachers.name) AS name, teachers.username, teacher_attendance.status
        FROM teacher_attendance
        JOIN teachers ON teachers.id = teacher_attendance.teacher_id
        ORDER BY teacher_attendance.date DESC, TRIM(teachers.name), teachers.id
        LIMIT 20
        """).fetchall()

    return render_template(
        "admin/teacher_attendance.html",
        teachers=teachers,
        selected_date=selected_date,
        success=success,
        attendance_map=attendance_map,
        recent_rows=recent_rows
    )


@app.route("/teacher_attendance_report")
def teacher_attendance_report():
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect("/attendance")

    selected_date = request.args.get("date", "").strip()
    teacher_username = session.get("user") if session.get("role") == "teacher" else ""
    report_data = get_teacher_attendance_report(selected_date, teacher_username)
    is_teacher_view = session.get("role") == "teacher"

    return render_template(
        "admin/teacher_attendance_report.html",
        selected_date=selected_date,
        summary=report_data["summary"],
        details=report_data["details"],
        total_present=report_data["total_present"],
        total_absent=report_data["total_absent"],
        total_records=report_data["total_records"],
        overall_percent=report_data["overall_percent"],
        chart_labels=report_data["chart_labels"],
        chart_present=report_data["chart_present"],
        chart_absent=report_data["chart_absent"],
        is_teacher_view=is_teacher_view,
        report_teacher_id=None,
    )


@app.route("/teacher_report/<int:id>")
def teacher_report(id):
    if not can_access_teacher_report(id):
        return redirect("/")

    selected_date = request.args.get("date", "").strip()
    report_data = get_teacher_attendance_report(selected_date, teacher_id=id)
    is_teacher_view = session.get("role") == "teacher"

    if not report_data["summary"]:
        return redirect("/teachers" if session.get("role") == "admin" else "/teacher")

    return render_template(
        "admin/teacher_attendance_report.html",
        selected_date=selected_date,
        summary=report_data["summary"],
        details=report_data["details"],
        total_present=report_data["total_present"],
        total_absent=report_data["total_absent"],
        total_records=report_data["total_records"],
        overall_percent=report_data["overall_percent"],
        chart_labels=report_data["chart_labels"],
        chart_present=report_data["chart_present"],
        chart_absent=report_data["chart_absent"],
        is_teacher_view=is_teacher_view,
        report_teacher_id=id,
    )


@app.route("/teacher_attendance_download")
def teacher_attendance_download():
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect("/attendance")

    selected_date = request.args.get("date", "").strip()
    teacher_username = session.get("user") if session.get("role") == "teacher" else ""
    teacher_id = request.args.get("teacher_id", "").strip()
    teacher_id = int(teacher_id) if teacher_id.isdigit() else None
    if teacher_id is not None and not can_access_teacher_report(teacher_id):
        return redirect("/")

    report_data = get_teacher_attendance_report(selected_date, teacher_username, teacher_id)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Teacher Attendance Report"])
    writer.writerow(["Date Filter", selected_date or "All Dates"])
    writer.writerow([])
    writer.writerow(["Summary"])
    writer.writerow(["ID", "Name", "Username", "Course", "Subject", "Present", "Absent", "Total", "Percentage"])

    for row in report_data["summary"]:
        total_count = row["total_count"] or 0
        present_count = row["present_count"] or 0
        absent_count = row["absent_count"] or 0
        percentage = round((present_count * 100 / total_count), 1) if total_count else 0
        writer.writerow([
            row["id"],
            row["name"],
            row["username"] or "-",
            row["course"] or "-",
            row["subject"] or "-",
            present_count,
            absent_count,
            total_count,
            f"{percentage}%"
        ])

    writer.writerow([])
    writer.writerow(["Details"])
    writer.writerow(["Date", "Teacher ID", "Name", "Username", "Course", "Subject", "Status"])

    for row in report_data["details"]:
        writer.writerow([
            row["date"],
            row["teacher_id"],
            row["name"],
            row["username"] or "-",
            row["course"] or "-",
            row["subject"] or "-",
            row["status"]
        ])

    if teacher_id is not None and report_data["summary"]:
        filename_base = f"teacher_attendance_{report_data['summary'][0]['id']}"
    else:
        filename_base = f"teacher_attendance_{teacher_username}" if teacher_username else "teacher_attendance"
    filename = (
        f"{filename_base}_{selected_date}.csv"
        if selected_date
        else f"{filename_base}_all_dates.csv"
    )
    response = make_response(output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


# COURSE CRUD
@app.route("/courses")
def list_courses():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    with db() as con:
        courses = con.execute("SELECT * FROM courses").fetchall()
    return render_template("admin/courses.html", courses=courses)


@app.route("/add_course", methods=["GET", "POST"])
def add_course():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    if request.method == "POST":
        f = request.form
        with db() as con:
            con.execute("INSERT INTO courses(name,description) VALUES (?,?)", (
                f.get("name"), f.get("description")
            ))
        return redirect("/courses")
    return render_template("admin/add_course.html")


@app.route("/edit_course/<int:id>", methods=["GET", "POST"])
def edit_course(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    with db() as con:
        course = con.execute("SELECT * FROM courses WHERE id=?", (id,)).fetchone()
        if request.method == "POST":
            f = request.form
            con.execute("UPDATE courses SET name=?, description=? WHERE id=?", (
                f.get("name"), f.get("description"), id
            ))
            return redirect("/courses")
    return render_template("admin/edit_course.html", course=course)


@app.route("/delete_course/<int:id>")
def delete_course(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        con.execute("DELETE FROM courses WHERE id=?", (id,))
    return redirect("/courses")


# SUBJECT CRUD
@app.route("/subjects")
def list_subjects():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    with db() as con:
        subjects = con.execute("SELECT * FROM subjects").fetchall()
    return render_template("admin/subjects.html", subjects=subjects)


@app.route("/add_subject", methods=["GET", "POST"])
def add_subject():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    if request.method == "POST":
        f = request.form
        course = f.get("course")
        new_course = f.get("new_course")

        with db() as con:
            if new_course and new_course.strip():
                course = new_course.strip()
                # Insert course if not already existing
                existing = con.execute("SELECT id FROM courses WHERE name=?", (course,)).fetchone()
                if not existing:
                    con.execute("INSERT INTO courses(name,description) VALUES (?,?)", (course, f.get("course_description", "Added from subject")))

            con.execute("INSERT INTO subjects(name,course) VALUES (?,?)", (
                f.get("name"), course
            ))

        return redirect("/subjects")
    courses = []
    with db() as con:
        courses = con.execute("SELECT name FROM courses").fetchall()
    return render_template("admin/add_subject.html", courses=courses)


@app.route("/edit_subject/<int:id>", methods=["GET", "POST"])
def edit_subject(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")
    with db() as con:
        subject = con.execute("SELECT * FROM subjects WHERE id=?", (id,)).fetchone()
        if request.method == "POST":
            f = request.form
            con.execute("UPDATE subjects SET name=?, course=? WHERE id=?", (
                f.get("name"), f.get("course"), id
            ))
            return redirect("/subjects")
    courses = con.execute("SELECT name FROM courses").fetchall()
    return render_template("admin/edit_subject.html", subject=subject, courses=courses)


@app.route("/delete_subject/<int:id>")
def delete_subject(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        con.execute("DELETE FROM subjects WHERE id=?", (id,))
    return redirect("/subjects")


# VIEW ATTENDANCE (existing)
@app.route("/view_attendance")
def view_attendance():
    return redirect("/attendance")


# UPDATE USER
@app.route("/update/<int:id>", methods=["GET","POST"])
def update(id):
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect("/attendance")

    with db() as con:

        if request.method=="POST":

            f=request.form
            file=request.files.get("photo")

            old=con.execute(
            "SELECT photo FROM users WHERE id=?",
            (id,)
            ).fetchone()

            duplicate = con.execute(
                "SELECT id FROM users WHERE username=? AND id<>?",
                (f["username"], id)
            ).fetchone()
            if duplicate:
                user = con.execute("SELECT * FROM users WHERE id=?", (id,)).fetchone()
                return render_template("update.html", user=user, msg="Username already exists")

            filename=old["photo"]

            if file and file.filename!="":

                filename = str(time.time()) + "_" + secure_filename(file.filename)

                path = os.path.join(app.config["UPLOAD_FOLDER"], filename)

                file.save(path)

            con.execute("""
            UPDATE users SET
            username=?,gender=?,mobile=?,address=?,photo=?,enroll=?,blood=?,school=?,birthdate=?
            WHERE id=?
            """,(f["username"],f["gender"],f["mobile"],f["address"],filename,f["enroll"],f["blood"],f["school"],f["birthdate"],id))

            return redirect("/list" if session.get("role") == "admin" else "/teacher")

        user=con.execute("SELECT * FROM users WHERE id=?",(id,)).fetchone()

    return render_template("update.html",user=user, msg="")


# DAILY ATTENDANCE
@app.route("/attendance", methods=["GET","POST"])
def attendance():
    if "user" not in session:
        return redirect("/")
    if session.get("role") == "student":
        return redirect("/my_attendance")

    with db() as con:

        success = request.args.get("saved", "")

        selected_date = request.values.get("date", date.today().isoformat()) or date.today().isoformat()
        leave_students = get_students_on_approved_leave(con, selected_date)

        if request.method=="POST":

            attendance_date = request.form["date"]
            leave_students = get_students_on_approved_leave(con, attendance_date)

            users=con.execute("""
            SELECT * FROM users
            WHERE role='student'
            ORDER BY rollno, username
        """).fetchall()

            for u in users:

                if u["id"] in leave_students:
                    status = "Leave"
                else:
                    status = request.form.get(f"status_{u['id']}")

                if not status:
                    continue

                check=con.execute(
                "SELECT * FROM attendance WHERE student_id=? AND date=?",
                (u["id"],attendance_date)
                ).fetchone()

                if check:

                    con.execute(
                    "UPDATE attendance SET status=? WHERE student_id=? AND date=?",
                    (status,u["id"],attendance_date)
                    )

                else:

                    con.execute(
                    "INSERT INTO attendance(student_id,date,status) VALUES (?,?,?)",
                    (u["id"],attendance_date,status)
                    )

            return redirect(f"/attendance?saved=1&date={attendance_date}")

        users=con.execute("""
            SELECT * FROM users
            WHERE role='student'
            ORDER BY rollno, username
        """).fetchall()

    return render_template(
        "attendance.html",
        users=users,
        success=success,
        is_teacher_view=session.get("role") == "teacher",
        selected_date=selected_date,
        leave_students=leave_students
    )

# TIMETABLE PAGE
@app.route("/timetable")
def timetable():
    if "user" not in session:
        return redirect("/")

    with db() as con:
        ensure_six_month_timetable(con)
    return render_template(
        "timetable.html",
        weekly_timetable=get_weekly_timetable(),
        is_student_view=session.get("role") == "student",
    )
# GENERATE TIMETABLE
@app.route("/generate_auto_timetable")
def generate_auto_timetable():
    if "user" not in session:
        return redirect("/")
    if session.get("role") != "admin":
        return redirect("/attendance")

    with db() as con:
        ensure_six_month_timetable(con, reset=True)

    return redirect("/timetable")
# LECTURE ATTENDANCE
@app.route("/lecture_attendance",methods=["GET","POST"])
def lecture_attendance():
    if "user" not in session:
        return redirect("/")
    if session.get("role") not in ("admin", "teacher"):
        return redirect("/my_attendance")

    with db() as con:
        ensure_six_month_timetable(con)

        users=con.execute("""
            SELECT * FROM users
            WHERE role='student'
            ORDER BY rollno, username
        """).fetchall()
        lectures = con.execute("""
        SELECT id, lecture_date, day, lecture_name, time
        FROM lectures
        ORDER BY lecture_date, id
        """).fetchall()
        selected_date = request.values.get("date", date.today().isoformat()) or date.today().isoformat()
        selected_lecture_id = request.values.get("lecture", "")
        success = request.args.get("saved", "")
        leave_students = get_students_on_approved_leave(con, selected_date)

        if request.method=="POST":

            lecture=request.form["lecture"]
            selected_lecture = con.execute(
                "SELECT lecture_date, day, lecture_name, time FROM lectures WHERE id=?",
                (lecture,)
            ).fetchone()
            attendance_date = request.form.get("date") or (selected_lecture["lecture_date"] if selected_lecture else "")
            attendance_day = (
                selected_lecture["day"]
                if selected_lecture and selected_lecture["lecture_date"] == attendance_date
                else get_attendance_day_name(attendance_date)
            )
            lecture_name = selected_lecture["lecture_name"] if selected_lecture else ""
            lecture_time = selected_lecture["time"] if selected_lecture else ""
            leave_students = get_students_on_approved_leave(con, attendance_date)

            for u in users:

                if u["id"] in leave_students:
                    status = "Leave"
                else:
                    status = request.form.get(f"status_{u['id']}")

                if not status:
                    continue

                check=con.execute("""
                SELECT * FROM lecture_attendance
                WHERE student_id=? AND date=? AND lecture_no=?
                """,(u["id"],attendance_date,lecture)).fetchone()

                if check:

                    con.execute("""
                    UPDATE lecture_attendance
                    SET status=?, lecture_day=?, lecture_name=?, lecture_time=?
                    WHERE student_id=? AND date=? AND lecture_no=?
                    """,(status,attendance_day,lecture_name,lecture_time,u["id"],attendance_date,lecture))

                else:

                    con.execute("""
                    INSERT INTO lecture_attendance(
                        student_id,date,lecture_no,status,lecture_day,lecture_name,lecture_time
                    )
                    VALUES (?,?,?,?,?,?,?)
                    """,(u["id"],attendance_date,lecture,status,attendance_day,lecture_name,lecture_time))

            return redirect(f"/lecture_attendance?date={attendance_date}&lecture={lecture}&saved=1")

    return render_template(
        "lecture_attendance.html",
        users=users,
        lectures=lectures,
        selected_date=selected_date,
        selected_lecture_id=selected_lecture_id,
        leave_students=leave_students,
        success=success
    )


@app.route("/festivals")
def festivals():
    if "user" not in session:
        return redirect("/")

    with db() as con:
        ensure_festival_calendar(con)
        data = con.execute("""
        SELECT festival_date, day, name, holiday_type, note
        FROM festivals
        ORDER BY festival_date, id
        """).fetchall()

    return render_template("festivals.html", data=data, is_student_view=session.get("role") == "student")


@app.route("/weekly_attendance")
def weekly_attendance():
    if "user" not in session:
        return redirect("/")

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    with db() as con:
        ensure_six_month_timetable(con)
        if session.get("role") == "student":
            summary = con.execute("""
            SELECT
                users.id,
                users.rollno,
                users.username,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status='Absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE users.id=?
            GROUP BY users.id, users.rollno, users.username
            """, (user["id"],)).fetchall()

            lectures = get_lecture_attendance_rows(
                con,
                "WHERE users.id=?",
                (user["id"],)
            )
        else:
            summary = con.execute("""
            SELECT
                users.id,
                users.rollno,
                users.username,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status='Absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE users.role='student'
            GROUP BY users.id, users.rollno, users.username
            ORDER BY users.rollno, users.username
            """).fetchall()

            lectures = get_lecture_attendance_rows(
                con,
                "WHERE users.role='student'"
            )

    return render_template(
        "weekly_attendance.html",
        summary=summary,
        lectures=lectures,
        is_student_view=session.get("role") == "student"
    )


# DATE REPORT
@app.route("/date/<date>")
def date_report(date):
    if "user" not in session:
        return redirect("/")
    if session.get("role") == "student":
        return redirect("/my_attendance")

    with db() as con:

        data=con.execute("""
        SELECT users.rollno,users.username,attendance.status
        FROM attendance
        JOIN users ON users.id=attendance.student_id
        WHERE attendance.date=?
        """,(date,)).fetchall()

    return render_template("day.html",data=data,date=date)


# STUDENT REPORT
@app.route("/report/<int:id>")
def report(id):
    if "user" not in session:
        return redirect("/")

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    if session.get("role") == "student" and user["id"] != id:
        return redirect("/my_attendance")

    report_data = get_student_attendance_report(id)
    if not report_data["student"]:
        return redirect("/attendance")

    return render_template(
    "report.html",
    data=report_data["data"],
    student=report_data["student"],
    present=report_data["present"],
    absent=report_data["absent"],
    leave=report_data["leave"],
    penalty=report_data["penalty"],
    recovery=report_data["recovery"],
    percent=report_data["percent"],
    report_type=report_data["report_type"],
    is_student_view=session.get("role") == "student"
    )


@app.route("/my_attendance")
def my_attendance():
    if "user" not in session:
        return redirect("/")

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    report_data = get_student_attendance_report(user["id"])
    if not report_data["student"]:
        return redirect("/")

    return render_template(
        "report.html",
        data=report_data["data"],
        student=report_data["student"],
        present=report_data["present"],
        absent=report_data["absent"],
        leave=report_data["leave"],
        penalty=report_data["penalty"],
        recovery=report_data["recovery"],
        percent=report_data["percent"],
        report_type=report_data["report_type"],
        is_student_view=True
    )


@app.route("/excel/<int:id>")
def export_attendance(id):
    if "user" not in session:
        return redirect("/")

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    if session.get("role") == "student" and user["id"] != id:
        return redirect("/my_attendance")

    report_data = get_student_attendance_report(id)
    student = report_data["student"]
    data = report_data["data"]
    if not student:
        return redirect("/attendance")

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Student Name", student["username"]])
    writer.writerow(["Roll No", student["rollno"]])
    writer.writerow([])
    writer.writerow(["Summary"])
    writer.writerow(["Present", report_data["present"]])
    writer.writerow(["Absent", report_data["absent"]])
    writer.writerow(["Leave", report_data["leave"]])
    writer.writerow(["Penalty %", report_data["penalty"]])
    writer.writerow(["Recovery %", report_data["recovery"]])
    writer.writerow(["Attendance %", report_data["percent"]])
    writer.writerow([])
    if report_data["report_type"] == "lecture":
        writer.writerow(["Date", "Day", "Subject", "Time", "Status"])
        for row in data:
            writer.writerow([
                row["date"],
                row["day"] or "-",
                row["lecture_name"] or "-",
                row["time"] or "-",
                row["status"]
            ])
    else:
        writer.writerow(["Date", "Status"])
        for row in data:
            writer.writerow([row["date"], row["status"]])

    response = make_response(output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = (
        f'attachment; filename="attendance_report_{student["username"]}.csv"'
    )
    return response


@app.route("/weekly_attendance_download")
def weekly_attendance_download():
    if "user" not in session:
        return redirect("/")

    user = current_user()
    if user is None:
        session.clear()
        return redirect("/")

    with db() as con:
        ensure_six_month_timetable(con)

        if session.get("role") == "student":
            summary = con.execute("""
            SELECT
                users.rollno,
                users.username,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status='Absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE users.id=?
            GROUP BY users.id, users.rollno, users.username
            """, (user["id"],)).fetchall()

            lectures = get_lecture_attendance_rows(
                con,
                "WHERE users.id=?",
                (user["id"],)
            )
        else:
            summary = con.execute("""
            SELECT
                users.rollno,
                users.username,
                SUM(CASE WHEN lecture_attendance.status='Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN lecture_attendance.status='Absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN lecture_attendance.status IN ('Present', 'Absent') THEN 1 ELSE 0 END) AS total_count
            FROM users
            LEFT JOIN lecture_attendance ON lecture_attendance.student_id = users.id
            WHERE users.role='student'
            GROUP BY users.id, users.rollno, users.username
            ORDER BY users.rollno, users.username
            """).fetchall()

            lectures = get_lecture_attendance_rows(
                con,
                "WHERE users.role='student'"
            )

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Weekly Attendance Summary"])
    writer.writerow([])
    writer.writerow(["Roll No", "Name", "Present", "Absent", "Total Lectures", "Percentage"])

    for row in summary:
        total_count = row["total_count"] or 0
        present_count = row["present_count"] or 0
        absent_count = row["absent_count"] or 0
        percentage = round((present_count * 100 / total_count), 1) if total_count else 0
        writer.writerow([
            row["rollno"],
            row["username"],
            present_count,
            absent_count,
            total_count,
            f"{percentage}%"
        ])

    writer.writerow([])
    writer.writerow(["Lecture Attendance Details"])
    writer.writerow(["Date", "Day", "Subject", "Time", "Name", "Status"])

    for row in lectures:
        writer.writerow([
            row["date"],
            row["day"] or "-",
            row["lecture_name"] or "-",
            row["time"] or "-",
            row["username"],
            row["status"]
        ])

    filename = (
        f'weekly_attendance_{user["username"]}.csv'
        if session.get("role") == "student"
        else "weekly_attendance_all_students.csv"
    )
    response = make_response(output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


# LOGOUT
@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")


if __name__=="__main__":
    app.run(debug=True)
